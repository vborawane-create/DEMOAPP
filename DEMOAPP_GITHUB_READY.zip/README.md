# DEMOAPP
Excel-based car quotation app.

- Individual vs CSD price
- MH vs BH passing
- CSD TCS = 0
- TOUR restrictions and labels
- Quotation image (PNG) and share
- GitHub Actions builds APK without Android Studio

Upload the repository contents to GitHub, then open Actions → Build APK → Run workflow. The APK will be available under the workflow run Artifacts.
